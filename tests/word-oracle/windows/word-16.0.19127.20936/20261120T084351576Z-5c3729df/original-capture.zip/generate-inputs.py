"""Independent source-only glyph controls for the uncommitted PDF hypothesis."""
from pathlib import Path
from io import BytesIO
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import hashlib,json
from lxml import etree as E
T=Path(__file__).resolve().parent;R=T/'w19p'
q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
sha=lambda data:hashlib.sha256(data).hexdigest()
index=json.loads((R/'tests/word-oracle/windows/positive-kerning-observations.json').read_bytes())
out=T/'w20-device-writer-holdout-inputs';assert not out.exists();out.mkdir();facts=[]
for style in ('regular','bold','italic','bolditalic'):
    for size,points in (('14',14),('15p5',15.5)):
        parent_name=f'word-windows-positive-kern-{style}-s{size}-Z48-m14'
        parent,=[r for r in index['fixtures'] if r['name']==parent_name]
        original=(R/parent['source']['file']).read_bytes();assert sha(original)==parent['source']['sha256']
        for character in ('A','T','W'):
            with ZipFile(BytesIO(original)) as source:
                document=E.fromstring(source.read('word/document.xml'));texts=list(document.iter(q('t')))
                assert len(texts)==4 and all(t.text=='Z'*48 for t in texts)
                for text in texts:text.text=character*48
                changed=E.tostring(document,encoding='utf-8',xml_declaration=True,standalone=True)
                buffer=BytesIO()
                with ZipFile(buffer,'w',compression=ZIP_DEFLATED) as target:
                    for item in source.infolist():
                        info=ZipInfo(item.filename,(2026,11,20,0,0,0));info.create_system=0;info.compress_type=ZIP_DEFLATED;info.external_attr=item.external_attr
                        target.writestr(info,changed if item.filename=='word/document.xml' else source.read(item.filename))
                data=buffer.getvalue()
                with ZipFile(BytesIO(data)) as checked:
                    assert checked.namelist()==source.namelist()
                    assert all(checked.read(n)==source.read(n) for n in source.namelist() if n!='word/document.xml')
            name=f'word-windows-device-writer-holdout-{style}-s{size}-{character}48-m14';path=out/(name+'.docx');path.write_bytes(data)
            facts.append(dict(name=name,source=str(path),source_sha256=sha(data),derived_parent=parent['source'],parent_name=parent_name,font_family='Aptos Display',font_style=style,font_size_pt=points,compatibility_mode=14,character=character,length=48,paragraphs=4,expected_non_whitespace_glyphs=192,changed_parts=['word/document.xml']))
assert len(facts)==24
p=T/'w20-device-writer-holdout-input-facts.json';assert not p.exists();p.write_bytes((json.dumps(facts,indent=2)+'\n').encode())
print('Generated24 independent A/T/W source-only controls; unrelated parts byte-identical',flush=True)
