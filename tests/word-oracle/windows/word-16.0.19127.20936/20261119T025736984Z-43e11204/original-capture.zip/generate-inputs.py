from pathlib import Path
from io import BytesIO
from copy import deepcopy
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib
from lxml import etree as E
T=Path(__file__).resolve().parent
facts=json.loads((T/'w19-hard-break-input-facts.json').read_text(encoding='utf-8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
out=T/'w19-hard-break-ascii-inputs';assert not out.exists();out.mkdir();rows=[]
for mode in (14,15):
    for ending in ('manual','paragraph'):
        parent,=[r for r in facts if r['east_asia_font']=='Arial' and r['compatibility_mode']==mode
                 and r['line_ending']==ending and r['trailing_ascii_spaces']==0]
        data=Path(parent['source']).read_bytes();assert sha(data)==parent['source_sha256']
        for count in (0,3):
            with ZipFile(BytesIO(data)) as source:
                tree=E.fromstring(source.read('word/document.xml'));text=next(tree.iter(q('t')));text.text='AA BB'+' '*count
                xml=E.tostring(tree,encoding='utf-8',xml_declaration=True,standalone=True);buffer=BytesIO()
                with ZipFile(buffer,'w',compression=ZIP_DEFLATED) as target:
                    for info in source.infolist():target.writestr(deepcopy(info),xml if info.filename=='word/document.xml' else source.read(info.filename))
            result=buffer.getvalue();name=f'word-windows-hard-break-ascii-s12-m{mode}-{ending}-spaces{count}';dest=out/(name+'.docx');dest.write_bytes(result)
            rows.append(dict(name=name,source=str(dest),source_sha256=sha(result),derived_parent=dict(name=parent['name'],source_sha256=parent['source_sha256']),
                east_asia_font='Arial',font_size_pt=12,compatibility_mode=mode,line_ending=ending,trailing_ascii_spaces=count,
                text='AA BB'+' '*count,following_text='X' if ending=='manual' else '',expected_non_whitespace_glyphs=4+(ending=='manual'),changed_parts=['word/document.xml']))
p=T/'w19-hard-break-ascii-input-facts.json';assert not p.exists();p.write_bytes((json.dumps(rows,indent=2)+chr(10)).encode())
wrapper=(T/'capture-w19-y-length.ps1').read_text(encoding='utf-8-sig').replace('w19-y-length','w19-hard-break-ascii').replace('-ne 4','-ne 8').replace('Captured4 original y-length controls','Captured8 original ASCII hard-break controls')
p=T/'capture-w19-hard-break-ascii.ps1';assert not p.exists();p.write_bytes(wrapper.encode());print('Prepared8 pureASCII control documents',flush=True)
