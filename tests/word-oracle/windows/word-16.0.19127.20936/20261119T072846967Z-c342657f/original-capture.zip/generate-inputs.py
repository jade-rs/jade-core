from pathlib import Path
from io import BytesIO
from zipfile import ZipFile
import copy,hashlib,json,sys
from lxml import etree as E
from fontTools.ttLib import TTFont
T=Path(__file__).resolve().parent;R=T/'w19ma';sys.path.insert(0,str(R/'scripts/word-oracle'))
from generate_windows_legacy_justification_probes import changed_document
read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest();q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
parents={r['name']:r for r in read(R/'tests/word-oracle/windows/legacy-justification-observations.json')['fixtures']}
meta=read(T/'w19-ma1-native-exe.json');out=T/'w19-tight-face-inputs';assert not out.exists();out.mkdir();facts=[]
for left,right,label in [('Arial','Calibri','arial-calibri'),('Arial','Times New Roman','arial-times'),('Calibri','Times New Roman','calibri-times')]:
 for mode in (14,15):
  for splice,lefttext,righttext,group in [('after-abc','Ag日本語 ABC ','Ag日本語','mixed-face'),('after-cjk','Ag日本語 ','ABC Ag日本語','split-space-face')]:
   baseline=T/('w19-ma1-'+group+'24-original-xps')/f'word-windows-{group}-{label}-s12-m{mode}-paragraph-w3000';natural=read(baseline/'native.json')
   widths=[]
   for font in (baseline/'fonts').glob('*.ttf'):
    with TTFont(font) as face:
     cmap=face.getBestCmap() or {}
     if ord('語') in cmap:widths.append(face['hmtx'][cmap[ord('語')]][0]/face['head'].unitsPerEm*12)
   assert len(set(widths))==1 and ''.join(g[1] for g in natural['glyphs'])==lefttext+righttext
   extent=natural['glyphs'][-1][2]+widths[0]-natural['glyphs'][0][2];width=round((extent+1.5)*20)
   for ending in ('manual','paragraph'):
    parent=parents[f'word-windows-legacy-font-calibri-s12-m{mode}-{ending}-w3000'];source=(R/parent['source']['file']).read_bytes();assert sha(source)==parent['source']['sha256']
    with ZipFile(BytesIO(source)) as package:document=E.fromstring(package.read('word/document.xml'))
    paragraph,=document.iter(q('p'));paragraph.find(q('pPr')).find(q('ind')).set(q('right'),str(8504-width))
    second,=paragraph.iter(q('r'));first=copy.deepcopy(second)
    for node in list(first):
     if node.tag!=q('rPr'):first.remove(node)
    text=E.Element(q('t'));text.set('{http://www.w3.org/XML/1998/namespace}space','preserve');text.text=lefttext;first.append(text)
    next(second.iter(q('t'))).text=righttext
    for run,family in ((first,left),(second,right)):
     fonts=run.find(q('rPr')).find(q('rFonts'))
     for slot in ('ascii','hAnsi','cs'):fonts.set(q(slot),family)
    paragraph.insert(list(paragraph).index(second),first)
    data=changed_document(source,E.tostring(document,encoding='utf-8',xml_declaration=True,standalone=True))
    with ZipFile(BytesIO(source)) as old,ZipFile(BytesIO(data)) as new:assert all(old.read(n)==new.read(n) for n in old.namelist() if n!='word/document.xml')
    name=f'word-windows-tight-face-{splice}-{label}-s12-m{mode}-{ending}-w{width}';path=out/(name+'.docx');path.write_bytes(data)
    facts.append(dict(name=name,source=str(path),source_sha256=sha(data),derived_parent=parent['source'],left_font_family=left,right_font_family=right,font_size_pt=12,compatibility_mode=mode,line_ending=ending,line_width_twips=width,left_text=lefttext,right_text=righttext,following_text='X' if ending=='manual' else '',expected_non_whitespace_glyphs=14 if ending=='manual' else 13,changed_parts=['word/document.xml'],width_probe=dict(source='Native natural metrics plus1.5pt, no Word positions',native_executable_sha256=meta['sha256'],natural_input_sha256=natural['input_sha256'],natural_json_sha256=sha((baseline/'native.json').read_bytes()),natural_extent_pt=extent,terminal_font_advance_pt=widths[0])))
assert len(facts)==24 and len({r['source_sha256'] for r in facts})==24
(T/'w19-tight-face-input-facts.json').write_bytes((json.dumps(facts,ensure_ascii=False,indent=2)+chr(10)).encode())
wrapper=(T/'capture-w19-space-pair.ps1').read_text(encoding='utf-8-sig').replace('w19-space-pair','w19-tight-face').replace('-ne 32','-ne 24').replace('Captured32 original space-pair controls','Captured24 original tight-face controls')
(T/'capture-w19-tight-face.ps1').write_bytes(wrapper.encode())
print('Prepared24 source-metric near-fit controls to test partial word-space expansion across faces; Word positions not used',flush=True)