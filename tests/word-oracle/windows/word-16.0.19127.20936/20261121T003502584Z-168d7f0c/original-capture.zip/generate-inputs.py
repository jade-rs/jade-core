"""Reproduce mixed-character controls from byte-verified original size inputs."""
from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from io import BytesIO
from lxml import etree as E
import hashlib,json
T=Path(__file__).resolve().parent;W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';sha=lambda b:hashlib.sha256(b).hexdigest()
parents=json.loads((T/'w20-long-size-high-input-facts.json').read_bytes());facts=json.loads((T/'w21-long-mixed8-input-facts.json').read_bytes())
for fact in facts:
 parent,=[r for r in parents if r['source_sha256']==fact['parent_source_sha256']]
 data=Path(parent['source']).read_bytes();assert sha(data)==parent['source_sha256']
 with ZipFile(BytesIO(data)) as z:
  tree=E.fromstring(z.read('word/document.xml'));nodes=list(tree.iter(W+'t'));assert len(nodes)==4
  for node,part in zip(nodes,fact['paragraph_specifications']):
   assert node.text=='@'*part['length'];node.text=part['text']
  xml=E.tostring(tree,encoding='utf-8',xml_declaration=True,standalone=True);buf=BytesIO()
  with ZipFile(buf,'w',ZIP_DEFLATED) as target:
   for item in z.infolist():
    info=ZipInfo(item.filename,(2026,11,21,0,0,0));info.create_system=0;info.compress_type=ZIP_DEFLATED;info.external_attr=item.external_attr;target.writestr(info,xml if item.filename=='word/document.xml' else z.read(item.filename))
  result=buf.getvalue();assert sha(result)==fact['source_sha256']
  p=Path(fact['source'])
  if p.exists():assert p.read_bytes()==result
  else:p.write_bytes(result)
print('Reproduced8 exact source inputs; no expected coordinates')
