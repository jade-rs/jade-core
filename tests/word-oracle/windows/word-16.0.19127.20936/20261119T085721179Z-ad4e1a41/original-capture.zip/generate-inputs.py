from pathlib import Path
from io import BytesIO
from zipfile import ZipFile
import copy,hashlib,json,sys
from lxml import etree as E
T=Path(__file__).resolve().parent;R=T/'w19mf';sys.path.insert(0,str(R/'scripts/word-oracle'))
from generate_windows_legacy_justification_probes import changed_document
read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest();q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
parents={r['name']:r for r in read(R/'tests/word-oracle/windows/legacy-justification-observations.json')['fixtures']}
out=T/'w19-mixed-size-inputs';assert not out.exists();out.mkdir();facts=[]
for left,right,label in [('Arial','Calibri','arial-calibri'),('Arial','Times New Roman','arial-times'),('Calibri','Times New Roman','calibri-times')]:
 for leftsize,rightsize in ((10,16),(16,10)):
  for mode in (14,15):
   for ending in ('manual','paragraph'):
    parent=parents[f'word-windows-legacy-font-calibri-s12-m{mode}-{ending}-w8504'];source=(R/parent['source']['file']).read_bytes();assert sha(source)==parent['source']['sha256']
    with ZipFile(BytesIO(source)) as package:document=E.fromstring(package.read('word/document.xml'))
    paragraph,=document.iter(q('p'));second,=paragraph.iter(q('r'));first=copy.deepcopy(second)
    for node in list(first):
     if node.tag!=q('rPr'):first.remove(node)
    text=E.Element(q('t'));text.set('{http://www.w3.org/XML/1998/namespace}space','preserve');text.text='Ag日本語 ';first.append(text)
    next(second.iter(q('t'))).text='ABC Ag日本語'
    for run,family,size in ((first,left,leftsize),(second,right,rightsize)):
     properties=run.find(q('rPr'));fonts=properties.find(q('rFonts'))
     for slot in ('ascii','hAnsi','cs'):fonts.set(q(slot),family)
     for tag in ('sz','szCs'):
      node=properties.find(q(tag));assert node is not None;node.set(q('val'),str(size*2))
    paragraph.insert(list(paragraph).index(second),first)
    data=changed_document(source,E.tostring(document,encoding='utf-8',xml_declaration=True,standalone=True))
    with ZipFile(BytesIO(source)) as old,ZipFile(BytesIO(data)) as new:assert all(old.read(n)==new.read(n) for n in old.namelist() if n!='word/document.xml')
    name=f'word-windows-mixed-size-{label}-s{leftsize}-{rightsize}-m{mode}-{ending}-w8504';path=out/(name+'.docx');path.write_bytes(data)
    facts.append(dict(name=name,source=str(path),source_sha256=sha(data),derived_parent=parent['source'],left_font_family=left,right_font_family=right,left_font_size_pt=leftsize,right_font_size_pt=rightsize,compatibility_mode=mode,line_ending=ending,line_width_twips=8504,left_text='Ag日本語 ',right_text='ABC Ag日本語',following_text='X' if ending=='manual' else '',expected_non_whitespace_glyphs=14 if ending=='manual' else 13,changed_parts=['word/document.xml']))
assert len(facts)==24 and len({r['source_sha256'] for r in facts})==24
(T/'w19-mixed-size-input-facts.json').write_bytes((json.dumps(facts,ensure_ascii=False,indent=2)+chr(10)).encode())
wrapper=(T/'capture-w19-space-pair.ps1').read_text(encoding='utf-8-sig').replace('w19-space-pair','w19-mixed-size').replace('-ne 32','-ne 24').replace('Captured32 original space-pair controls','Captured24 original mixed-size controls')
(T/'capture-w19-mixed-size.ps1').write_bytes(wrapper.encode())
print('Prepared24 two-face/two-size10/16 controls; onlydocument.xml runfonts/sizes/textsplit; natural/manual controls',flush=True)