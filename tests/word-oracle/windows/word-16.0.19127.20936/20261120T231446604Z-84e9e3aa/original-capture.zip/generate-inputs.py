from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from io import BytesIO
from lxml import etree as E
import json,hashlib
T=Path(__file__).resolve().parent;W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';sha=lambda b:hashlib.sha256(b).hexdigest();parents=json.loads((T/'w21-font-family-extended-input-facts.json').read_bytes());parents=[r for r in parents if r['canonical_family']=='Yu Mincho' and r['font_family_case']=='canonical' and r['compatibility_mode']==15 and r['line_ending']=='paragraph' and r['line_width_twips']==8504];assert len(parents)==1;parent=parents[0];data=Path(parent['source']).read_bytes();assert sha(data)==parent['source_sha256'];pairs=sorted(set([(w,16838) for w in range(11902,11911)]+[(11906,h) for h in range(16834,16843)]));assert len(pairs)==17;out=T/'w21-paper-grid17-inputs';assert not out.exists();out.mkdir();rows=[]
for width,height in pairs:
 with ZipFile(BytesIO(data)) as z:
  root=E.fromstring(z.read('word/document.xml'));section=root.find('.//'+W+'sectPr');page=section.find(W+'pgSz');assert page.get(W+'w')=='11906' and page.get(W+'h')=='16838';page.set(W+'w',str(width));page.set(W+'h',str(height));margin=section.find(W+'pgMar');xml=E.tostring(root,encoding='utf-8',xml_declaration=True,standalone=True);buffer=BytesIO()
  with ZipFile(buffer,'w',ZIP_DEFLATED) as target:
   for item in z.infolist():
    info=ZipInfo(item.filename,(2026,11,21,0,0,0));info.create_system=0;info.compress_type=ZIP_DEFLATED;info.external_attr=item.external_attr;target.writestr(info,xml if item.filename=='word/document.xml' else z.read(item.filename))
  result=buffer.getvalue()
  with ZipFile(BytesIO(result)) as check:assert z.namelist()==check.namelist() and all(z.read(n)==check.read(n) for n in z.namelist() if n!='word/document.xml')
 name=f'word-windows-paper-grid-w{width}-h{height}-m15';p=out/(name+'.docx');p.write_bytes(result);rows.append(dict(parent,name=name,source=str(p),source_sha256=sha(result),parent_source_sha256=parent['source_sha256'],page_width_twips=width,page_height_twips=height,line_width_twips=width-int(margin.get(W+'left'))-int(margin.get(W+'right')),source_change='Only authored section page width/height, including half-device-pixel boundaries. Other package parts and text/style remain byte-identical. No expected coordinates generated.'))
assert len({r['source_sha256'] for r in rows})==17;(T/'w21-paper-grid17-input-facts.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print('Generated17 original page-grid controls; real Word capture required',flush=True)
