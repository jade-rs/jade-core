from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from io import BytesIO
from lxml import etree as E
import json,hashlib
T=Path(__file__).resolve().parent;W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';sha=lambda b:hashlib.sha256(b).hexdigest();parents=[f for f in json.loads((T/'w19-aptos-mixed-face-input-facts.json').read_bytes()) if f['left_font_family']==f['right_font_family']=='Aptos Display'];assert len(parents)==8
out=T/'w21-font-family-cjk-style-inputs';assert not out.exists();out.mkdir();rows=[]
for parent in parents:
 source=Path(parent['source']);data=source.read_bytes();assert sha(data)==parent['source_sha256']
 for style,bold,italic in [('bold',True,False),('italic',False,True),('bold-italic',True,True)]:
  for token,family in [('canonical','Aptos Display'),('lower','aptos display'),('upper','APTOS DISPLAY'),('mixed','aPtOs dIsPlAy')]:
   with ZipFile(BytesIO(data)) as z:
    tree=E.fromstring(z.read('word/document.xml'));props=list(tree.iter(W+'rPr'));assert len(props)==2
    for prop in props:
     for tag,enabled in [('b',bold),('bCs',bold),('i',italic),('iCs',italic)]:
      assert prop.find(W+tag) is None
      if enabled:E.SubElement(prop,W+tag)
     font=prop.find(W+'rFonts');assert font is not None
     for key,value in list(font.attrib.items()):
      if value=='Aptos Display':font.set(key,family)
    xml=E.tostring(tree,encoding='utf-8',xml_declaration=True,standalone=True);buffer=BytesIO()
    with ZipFile(buffer,'w',ZIP_DEFLATED) as target:
     for item in z.infolist():
      info=ZipInfo(item.filename,(2026,11,21,0,0,0));info.create_system=0;info.compress_type=ZIP_DEFLATED;info.external_attr=item.external_attr;target.writestr(info,xml if item.filename=='word/document.xml' else z.read(item.filename))
    result=buffer.getvalue()
    with ZipFile(BytesIO(result)) as check:assert z.namelist()==check.namelist() and all(z.read(n)==check.read(n) for n in z.namelist() if n!='word/document.xml')
   name=parent['name'].replace('word-windows-aptos-mixed-face-aptos-display',f'word-windows-family-cjk-style-{style}-{token}');path=out/(name+'.docx');path.write_bytes(result)
   rows.append(dict(parent,name=name,source=str(path),source_sha256=sha(result),parent_name=parent['name'],canonical_parent_source=str(source),canonical_parent_sha256=parent['source_sha256'],style=style,bold=bold,italic=italic,left_font_family=family,right_font_family=family,font_family_case=token,changed_parts=['word/document.xml'],source_change='Only explicit style flags and family-name case; new actual Word capture required.'))
assert len(rows)==96;p=T/'w21-font-family-cjk-style-input-facts.json';assert not p.exists();p.write_bytes((json.dumps(rows,indent=2)+'\n').encode());print('Generated96 mixed-script styled controls, 24titlecase+72aliases; no expectations generated',flush=True)
