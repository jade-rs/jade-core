from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from io import BytesIO
from lxml import etree as E
import hashlib,json
T=Path(__file__).resolve().parent;W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';sha=lambda b:hashlib.sha256(b).hexdigest()
parents=json.loads((T/'w21-font-family-extended-input-facts.json').read_bytes())+json.loads((T/'w21-other-latin-style-input-facts.json').read_bytes())
parents=[f for f in parents if f['canonical_family'] in ('Century','Bookman Old Style') and f['font_family_case']=='canonical'];assert len(parents)==64
out=T/'w21-other-latin-balanced64-inputs';assert not out.exists();out.mkdir();rows=[]
for f in parents:
 data=Path(f['source']).read_bytes();assert sha(data)==f['source_sha256']
 with ZipFile(BytesIO(data)) as z:
  tree=E.fromstring(z.read('word/settings.xml'));node=tree.find(W+'compat/'+W+'balanceSingleByteDoubleByteWidth');assert node is not None and node.get(W+'val')=='0';node.set(W+'val','1');xml=E.tostring(tree,encoding='utf-8',xml_declaration=True,standalone=True);buf=BytesIO()
  with ZipFile(buf,'w',ZIP_DEFLATED) as target:
   for item in z.infolist():
    info=ZipInfo(item.filename,(2026,11,21,0,0,0));info.create_system=0;info.compress_type=ZIP_DEFLATED;info.external_attr=item.external_attr;target.writestr(info,xml if item.filename=='word/settings.xml' else z.read(item.filename))
  result=buf.getvalue()
  with ZipFile(BytesIO(result)) as check:assert z.namelist()==check.namelist() and all(z.read(n)==check.read(n) for n in z.namelist() if n!='word/settings.xml')
 style=f.get('font_style','regular');face='century' if f['canonical_family']=='Century' else 'bookman';name=f"word-windows-other-latin-balanced-{face}-{style}-s12-m{f['compatibility_mode']}-{f['line_ending']}-w{f['line_width_twips']}";p=out/(name+'.docx');p.write_bytes(result);rows.append(dict(f,name=name,source=str(p),source_sha256=sha(result),font_style=style,balanced=True,parent_source_sha256=f['source_sha256'],source_change='Only balanceSingleByteDoubleByteWidth changed from0to1 in settings.xml; all document.xml runs/styles/text/breaks and other package parts retained. No expected coordinates.'))
assert len(rows)==64 and len({r['source_sha256'] for r in rows})==64
(T/'w21-other-latin-balanced64-input-facts.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print('Generated64 balanced Century/Bookman controls',flush=True)
