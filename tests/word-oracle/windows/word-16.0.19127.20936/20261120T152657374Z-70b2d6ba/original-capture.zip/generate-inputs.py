from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from io import BytesIO
from lxml import etree as E
import hashlib,json
T=Path(__file__).resolve().parent;W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';sha=lambda b:hashlib.sha256(b).hexdigest();facts=json.loads((T/'w19-aptos-mixed-face-input-facts.json').read_bytes());parents=[f for f in facts if f['left_font_family']==f['right_font_family']=='Aptos Display'];assert len(parents)==8;out=T/'w21-font-family-cjk-case-inputs';assert not out.exists();out.mkdir();rows=[]
for old in parents:
 source=Path(old['source']);data=source.read_bytes();assert sha(data)==old['source_sha256']
 for token,family in [('lower','aptos display'),('upper','APTOS DISPLAY'),('mixed','aPtOs dIsPlAy')]:
  with ZipFile(BytesIO(data)) as z:
   tree=E.fromstring(z.read('word/document.xml'));changed_count=0
   for font in tree.iter(W+'rFonts'):
    for key,value in list(font.attrib.items()):
     if value=='Aptos Display':font.set(key,family);changed_count+=1
   assert changed_count>=4;xml=E.tostring(tree,encoding='utf-8',xml_declaration=True,standalone=True);b=BytesIO()
   with ZipFile(b,'w',ZIP_DEFLATED) as target:
    for item in z.infolist():
     info=ZipInfo(item.filename,(2026,11,21,0,0,0));info.create_system=0;info.compress_type=ZIP_DEFLATED;info.external_attr=item.external_attr;target.writestr(info,xml if item.filename=='word/document.xml' else z.read(item.filename))
   result=b.getvalue()
   with ZipFile(BytesIO(result)) as check:assert check.namelist()==z.namelist() and all(check.read(n)==z.read(n) for n in z.namelist() if n!='word/document.xml')
  name=old['name'].replace('word-windows-aptos-mixed-face-aptos-display',f'word-windows-family-cjk-case-{token}');path=out/(name+'.docx');path.write_bytes(result);rows.append(dict(old,name=name,source=str(path),source_sha256=sha(result),parent_name=old['name'],canonical_source=str(source),canonical_source_sha256=old['source_sha256'],left_font_family=family,right_font_family=family,font_family_case=token,changed_font_attributes=changed_count))
assert len(rows)==24;p=T/'w21-font-family-cjk-case-input-facts.json';assert not p.exists();p.write_bytes((json.dumps(rows,indent=2)+'\n').encode());print('Generated24mixedJapanese/Latinface-casecontrols;onlyfontnamecasechanged',flush=True)
