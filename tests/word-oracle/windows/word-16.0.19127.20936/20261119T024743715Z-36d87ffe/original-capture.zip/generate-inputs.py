from pathlib import Path
from io import BytesIO
from copy import deepcopy
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import json,hashlib
from lxml import etree as E
T=Path(__file__).resolve().parent;Q=T/'w19yl'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
index=read(Q/'tests/word-oracle/windows/observations/index.json')
out=T/'w19-hard-break-inputs';assert not out.exists();out.mkdir();facts=[]
for family in ('arial','yu'):
    parent_name=f'word-windows-edge-terminal-script-arial-{family}-size12-ea-space-both-balance0-compat15'
    capture,=[r for r in index['captures'] if any(d['name']==parent_name for d in r['documents'])]
    with ZipFile(Q/capture['archive']) as bundle:data=bundle.read('inputs/'+parent_name+'.docx')
    document,=[r for r in capture['documents'] if r['name']==parent_name];assert sha(data)==document['source_sha256']
    for mode in (14,15):
        for ending in ('manual','paragraph'):
            for count in (0,1,3):
                with ZipFile(BytesIO(data)) as source:
                    tree=E.fromstring(source.read('word/document.xml'));settings=E.fromstring(source.read('word/settings.xml'))
                    paragraphs=list(tree.iter(q('p')));assert len(paragraphs)==1
                    run,=paragraphs[0].iter(q('r'));texts=list(run.iter(q('t')));br,=run.iter(q('br'))
                    assert len(texts)==2 and texts[0].text.endswith('Ag日本語 ') and texts[1].text=='X'
                    text=texts[0].text.rstrip(' ')+' '*count;texts[0].text=text
                    if ending=='paragraph':run.remove(br);run.remove(texts[1])
                    compat,=[c for c in settings.iter(q('compatSetting')) if c.get(q('name'))=='compatibilityMode']
                    assert compat.get(q('val'))=='15';compat.set(q('val'),str(mode))
                    changed={'word/document.xml':E.tostring(tree,encoding='utf-8',xml_declaration=True,standalone=True)}
                    if mode==14:changed['word/settings.xml']=E.tostring(settings,encoding='utf-8',xml_declaration=True,standalone=True)
                    if mode==15 and ending=='manual' and count==1:result=data;changed={}
                    else:
                        buffer=BytesIO()
                        with ZipFile(buffer,'w',compression=ZIP_DEFLATED) as target:
                            for info in source.infolist():
                                item=ZipInfo(info.filename,(2026,11,19,0,0,0));item.create_system=0;item.compress_type=ZIP_DEFLATED;item.external_attr=info.external_attr
                                target.writestr(item,changed.get(info.filename,source.read(info.filename)))
                        result=buffer.getvalue()
                    with ZipFile(BytesIO(result)) as generated:
                        assert generated.namelist()==source.namelist()
                        assert all(generated.read(n)==source.read(n) for n in source.namelist() if n not in changed)
                name=f'word-windows-hard-break-ea-{family}-s12-m{mode}-{ending}-spaces{count}'
                dest=out/(name+'.docx');dest.write_bytes(result)
                facts.append(dict(name=name,source=str(dest),source_sha256=sha(result),
                    derived_parent=dict(name=parent_name,source_sha256=document['source_sha256'],capture_id=capture['capture_id'],archive=capture['archive'],archive_sha256=capture['archive_sha256']),
                    east_asia_font='Arial' if family=='arial' else 'Yu Mincho',font_size_pt=12,compatibility_mode=mode,
                    line_ending=ending,trailing_ascii_spaces=count,text=text,following_text='X' if ending=='manual' else '',
                    expected_non_whitespace_glyphs=sum(not c.isspace() for c in text)+(ending=='manual'),
                    changed_parts=sorted(changed),unchanged_parent_bytes=(result==data)))
p=T/'w19-hard-break-input-facts.json';assert not p.exists();p.write_bytes((json.dumps(facts,indent=2,ensure_ascii=False)+chr(10)).encode())
wrapper=(T/'capture-w19-y-length.ps1').read_text(encoding='utf-8-sig')
wrapper=wrapper.replace('w19-y-length','w19-hard-break').replace('-ne 4','-ne 24').replace('Captured4 original y-length controls','Captured24 original hard-break controls')
p=T/'capture-w19-hard-break.ps1';assert not p.exists();p.write_bytes(wrapper.encode());print('Prepared24 controlled Word inputs; two original-byte replay controls',flush=True)
