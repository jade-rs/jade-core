from pathlib import Path
from io import BytesIO
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import hashlib, json
from lxml import etree as E

T=Path(__file__).resolve().parent
N=T/'w19mf'
read=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
parents={r['name']:r for r in read(N/'tests/word-oracle/windows/legacy-justification-observations.json')['fixtures']}
batch='w19-times-ea-style-mode'
out=T/(batch+'-inputs')
assert not out.exists()
out.mkdir()
facts=[]
for mode,style in [(12,'regular'),(15,'regular'),(14,'bold'),(14,'italic'),(14,'bolditalic')]:
 for east,label in [('Arial','arial'),('Times New Roman','times')]:
  for balance in (0,1):
   for ending in ('manual','paragraph'):
    parent=parents[f'word-windows-legacy-font-times-s12-m14-{ending}-w8504']
    source=(N/parent['source']['file']).read_bytes()
    assert sha(source)==parent['source']['sha256']
    with ZipFile(BytesIO(source)) as package:
     document=E.fromstring(package.read('word/document.xml'))
     settings=E.fromstring(package.read('word/settings.xml'))
     run,=document.iter(q('r'))
     props=run.find(q('rPr'))
     fonts=props.find(q('rFonts'))
     assert fonts.get(q('ascii'))=='Times New Roman' and fonts.get(q('hAnsi'))=='Times New Roman'
     fonts.set(q('eastAsia'),east)
     for tag,enabled in [('b','bold' in style),('i','italic' in style)]:
      node=props.find(q(tag))
      if node is None:node=E.SubElement(props,q(tag))
      node.set(q('val'),'1' if enabled else '0')
     balanced,=settings.iter(q('balanceSingleByteDoubleByteWidth'))
     balanced.set(q('val'),str(balance))
     compatibility=[node for node in settings.iter(q('compatSetting')) if node.get(q('name'))=='compatibilityMode']
     assert len(compatibility)==1
     compatibility[0].set(q('val'),str(mode))
     replacements={name:E.tostring(root,encoding='utf-8',xml_declaration=True,standalone=True) for name,root in [('word/document.xml',document),('word/settings.xml',settings)]}
     buffer=BytesIO()
     with ZipFile(buffer,'w',compression=ZIP_DEFLATED) as target:
      for info in package.infolist():
       item=ZipInfo(info.filename,(2026,11,19,0,0,0));item.create_system=0;item.compress_type=ZIP_DEFLATED;item.external_attr=info.external_attr
       target.writestr(item,replacements.get(info.filename,package.read(info.filename)))
     data=buffer.getvalue()
     with ZipFile(BytesIO(data)) as target:
      assert all(package.read(n)==target.read(n) for n in package.namelist() if n not in replacements)
    name=f'word-windows-times-ea-style-mode-{label}-{style}-s12-m{mode}-balance{balance}-{ending}'
    path=out/(name+'.docx');path.write_bytes(data)
    facts.append(dict(name=name,source=str(path),source_sha256=sha(data),derived_parent=parent['source'],parent_name=parent['name'],font_family='Times New Roman',east_asia_font_family=east,font_style=style,font_size_pt=12,compatibility_mode=mode,balance_single_byte_double_byte_width=bool(balance),line_ending=ending,line_width_twips=8504,text='Ag日本語 ABC Ag日本語',following_text='X' if ending=='manual' else '',expected_non_whitespace_glyphs=14 if ending=='manual' else 13,changed_parts=list(replacements)))
assert len(facts)==len({r['source_sha256'] for r in facts})==40
(T/(batch+'-input-facts.json')).write_bytes((json.dumps(facts,ensure_ascii=False,indent=2)+'\n').encode())
wrapper=(T/'capture-w19-times-ea.ps1').read_text(encoding='utf-8-sig').replace('w19-times-ea',batch).replace('-ne 16','-ne 40').replace('Captured16 original Times East Asia requested-font controls','Captured40 original Times East Asia style/mode controls')
assert '-ne 16' not in wrapper
(T/('capture-'+batch+'.ps1')).write_bytes(wrapper.encode())
archive=(T/'archive-w19-times-ea-originals.py').read_text(encoding='utf-8-sig').replace('w19-times-ea',batch).replace("',16)","',40)")
assert "[('w19-times-ea-style-mode',40)]" in archive
(T/('archive-'+batch+'-originals.py')).write_bytes(archive.encode())
print('Prepared40 source-only Times EA controls: modes12/15 regular, mode14 bold/italic/bolditalic; each EAArial/Times, balanceoff/on, manual/natural',flush=True)
