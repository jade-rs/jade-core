"""Source-only length controls for Word's recorded advance distribution."""
from pathlib import Path
from io import BytesIO
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import hashlib
import json
from lxml import etree as E

T = Path(__file__).resolve().parent
R = T / 'w19p'
q = lambda s: '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}' + s
sha = lambda data: hashlib.sha256(data).hexdigest()
lengths = (1, 2, 3, 4, 7, 8, 12, 15, 16, 17, 31, 32, 33, 47, 48, 49, 64, 65)
parents = (
    ('positive-kerning-observations.json', 'word-windows-positive-kern-italic-s14-Z48-m14', 'Z', 'italic', 14),
    ('y-length-observations.json', 'word-windows-aptos-y-isolated48-regular-s15-m14', 'y', 'regular', 15),
)
out = T / 'w20-device-remainder-lengths-inputs'
assert not out.exists()
out.mkdir()
facts = []
for index, parent_name, character, style, points in parents:
    entries = json.loads((R / 'tests/word-oracle/windows' / index).read_bytes())['fixtures']
    parent, = [c for c in entries if c['name'] == parent_name]
    data = (R / parent['source']['file']).read_bytes()
    assert sha(data) == parent['source']['sha256']
    for length in lengths:
        with ZipFile(BytesIO(data)) as source:
            document = E.fromstring(source.read('word/document.xml'))
            texts = list(document.iter(q('t')))
            assert len(texts) in (2, 4) and all(t.text == character * 48 for t in texts)
            for text in texts:
                text.text = character * length
            new = E.tostring(document, encoding='utf-8', xml_declaration=True, standalone=True)
            output = BytesIO()
            with ZipFile(output, 'w', compression=ZIP_DEFLATED) as target:
                for item in source.infolist():
                    info = ZipInfo(item.filename, (2026, 11, 20, 0, 0, 0))
                    info.create_system = 0
                    info.compress_type = ZIP_DEFLATED
                    info.external_attr = item.external_attr
                    target.writestr(info, new if item.filename == 'word/document.xml' else source.read(item.filename))
            generated = output.getvalue()
            with ZipFile(BytesIO(generated)) as checked:
                assert checked.namelist() == source.namelist()
                assert all(checked.read(n) == source.read(n) for n in source.namelist() if n != 'word/document.xml')
        name = f'word-windows-device-remainder-{style}-s{points}-{character}{length}-m14'
        path = out / (name + '.docx')
        path.write_bytes(generated)
        facts.append(dict(name=name, source=str(path), source_sha256=sha(generated), derived_parent=parent['source'],
                          parent_name=parent_name, font_family='Aptos Display', font_style=style, font_size_pt=points,
                          compatibility_mode=14, character=character, length=length, paragraphs=len(texts),
                          expected_non_whitespace_glyphs=length * len(texts), changed_parts=['word/document.xml']))
assert len(facts) == 36
fact_file = T / 'w20-device-remainder-lengths-input-facts.json'
assert not fact_file.exists()
fact_file.write_text(json.dumps(facts, indent=2) + '\n', encoding='utf-8')
print('Generated36 independent source-only length controls; all unrelated package members byte-identical')
