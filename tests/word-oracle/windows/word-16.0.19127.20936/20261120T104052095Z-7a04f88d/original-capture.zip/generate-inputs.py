"""Source-only point-size holdouts for the accumulated Word width discrepancy."""
from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from io import BytesIO
from lxml import etree as E
import json,hashlib
T=Path(__file__).resolve().parent;R=T/'w19p';q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n;sha=lambda b:hashlib.sha256(b).hexdigest()
parents=json.loads((T/'w20-long-width-input-facts.json').read_bytes());out=T/'w20-long-size-inputs';assert not out.exists();out.mkdir();rows=[]
base=R/'tests/word-oracle/windows/word-16.0.19127.20936/20261120T101328742Z-8adf74bd/inputs'
for old in parents:
 p=base/(old['name']+'.docx');data=p.read_bytes();assert sha(data)==old['source_sha256']
 for token,points in [('13',13),('13p5',13.5),('14p5',14.5),('15',15),('15p5',15.5),('16',16)]:
  with ZipFile(BytesIO(data)) as z:
   tree=E.fromstring(z.read('word/document.xml'));sizes=list(tree.iter(q('sz')));assert len(sizes)==4 and all(s.get(q('val'))=='28' for s in sizes)
   for s in sizes:s.set(q('val'),str(int(points*2)))
   changed=E.tostring(tree,encoding='utf-8',xml_declaration=True,standalone=True);buf=BytesIO()
   with ZipFile(buf,'w',compression=ZIP_DEFLATED) as target:
    for item in z.infolist():
     info=ZipInfo(item.filename,(2026,11,20,0,0,0));info.create_system=0;info.compress_type=ZIP_DEFLATED;info.external_attr=item.external_attr;target.writestr(info,changed if item.filename=='word/document.xml' else z.read(item.filename))
   result=buf.getvalue()
   with ZipFile(BytesIO(result)) as check:assert check.namelist()==z.namelist() and all(check.read(n)==z.read(n) for n in z.namelist() if n!='word/document.xml')
  name=old['name'].replace('word-windows-long-width','word-windows-long-size').replace('-s14-',f'-s{token}-');path=out/(name+'.docx');path.write_bytes(result)
  f=dict(old,name=name,source=str(path),source_sha256=sha(result),parent_name=old['name'],derived_parent=dict(file=p.relative_to(R).as_posix(),sha256=old['source_sha256']),font_size_pt=points);rows.append(f)
assert len(rows)==48;p=T/'w20-long-size-input-facts.json';assert not p.exists();p.write_bytes((json.dumps(rows,indent=2)+'\n').encode());print('Generated48 source-only size controls;only four explicit run sizes changed;all other DOCX members identical',flush=True)