from pathlib import Path
from io import BytesIO
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import hashlib,json
from lxml import etree as E
T=Path(__file__).resolve().parent;R=T/'w19hs'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
index=read(R/'tests/word-oracle/windows/hard-break-space-observations.json')
out=T/'w19-legacy-width-inputs';assert not out.exists();out.mkdir();facts=[]
for mode in (14,15):
 for ending in ('manual','paragraph'):
  parent=next(c for c in index['fixtures'] if c['name']==f'word-windows-hard-break-ea-arial-s12-m{mode}-{ending}-spaces0')
  data=(R/parent['source']['file']).read_bytes();assert sha(data)==parent['source']['sha256']
  for width_twips in (6900,7000,7100,7200,7300,7700,8100,8504):
   with ZipFile(BytesIO(data)) as original:
    document=E.fromstring(original.read('word/document.xml'))
    paragraph,=document.iter(q('p'));properties=paragraph.find(q('pPr'))
    assert properties is not None and properties.find(q('ind')) is None
    section,=document.iter(q('sectPr'));page=section.find(q('pgSz'));margins=section.find(q('pgMar'))
    body_width=int(page.get(q('w')))-int(margins.get(q('left')))-int(margins.get(q('right')))
    assert body_width==8504
    indent=E.Element(q('ind'));indent.set(q('right'),str(body_width-width_twips));properties.insert(1,indent)
    xml=E.tostring(document,encoding='utf-8',xml_declaration=True,standalone=True)
    buffer=BytesIO()
    with ZipFile(buffer,'w',compression=ZIP_DEFLATED) as package:
     for info in original.infolist():
      item=ZipInfo(info.filename,(2026,11,19,0,0,0));item.create_system=0;item.compress_type=ZIP_DEFLATED;item.external_attr=info.external_attr
      package.writestr(item,xml if info.filename=='word/document.xml' else original.read(info.filename))
    result=buffer.getvalue()
    with ZipFile(BytesIO(result)) as package:
     assert package.namelist()==original.namelist()
     assert all(package.read(n)==original.read(n) for n in original.namelist() if n!='word/document.xml')
     check=E.fromstring(package.read('word/document.xml'));check.find('.//'+q('pPr')).remove(check.find('.//'+q('ind')))
     assert E.tostring(check)==E.tostring(E.fromstring(original.read('word/document.xml')))
   name=f'word-windows-legacy-width-arial-s12-m{mode}-{ending}-w{width_twips}'
   dest=out/(name+'.docx');dest.write_bytes(result)
   facts.append(dict(name=name,source=str(dest),source_sha256=sha(result),derived_parent=parent['source'],
    parent_name=parent['name'],compatibility_mode=mode,line_ending=ending,line_width_twips=width_twips,
    right_indent_twips=body_width-width_twips,text=parent['input_specification']['text'],
    following_text=parent['input_specification']['following_text'],
    expected_non_whitespace_glyphs=parent['input_specification']['expected_non_whitespace_glyphs'],
    changed_parts=['word/document.xml'],scope='Only right indent changes; source text, fonts, settings and other package parts are byte-preserved'))
p=T/'w19-legacy-width-input-facts.json';assert not p.exists();p.write_bytes((json.dumps(facts,ensure_ascii=False,indent=2)+chr(10)).encode())
wrapper=(T/'capture-w19-hard-break.ps1').read_text(encoding='utf-8-sig')
wrapper=wrapper.replace('w19-hard-break','w19-legacy-width').replace('-ne 24','-ne 32').replace('Captured24 original hard-break controls','Captured32 original legacy-width controls')
p=T/'capture-w19-legacy-width.ps1';assert not p.exists();p.write_bytes(wrapper.encode())
print('Prepared32 indentation-only controls across modes14/15 and345..425.2pt widths',flush=True)
