from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from io import BytesIO
from lxml import etree as E
import json,hashlib
T=Path(__file__).resolve().parent;q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
sha=lambda b:hashlib.sha256(b).hexdigest();facts=json.loads((T/'w20-long-width-input-facts.json').read_bytes());out=T/'w20-grid-disabled-inputs';assert not out.exists();out.mkdir();rows=[]
for old in facts:
 if (old['font_style'],old['paragraph_specifications'][0]['character']) not in (('italic','@'),('bolditalic','m')):continue
 data=Path(old['source']).read_bytes();assert sha(data)==old['source_sha256']
 with ZipFile(BytesIO(data)) as z:
  tree=E.fromstring(z.read('word/document.xml'));props=list(tree.iter(q('rPr')));assert len(props)==4
  for p in props:
   assert p.find(q('snapToGrid')) is None
   flag=E.SubElement(p,q('snapToGrid'));flag.set(q('val'),'0')
  changed=E.tostring(tree,encoding='utf-8',xml_declaration=True,standalone=True);buf=BytesIO()
  with ZipFile(buf,'w',compression=ZIP_DEFLATED) as target:
   for item in z.infolist():
    info=ZipInfo(item.filename,(2026,11,20,0,0,0));info.create_system=0;info.compress_type=ZIP_DEFLATED;info.external_attr=item.external_attr;target.writestr(info,changed if item.filename=='word/document.xml' else z.read(item.filename))
  result=buf.getvalue()
  with ZipFile(BytesIO(result)) as check:assert check.namelist()==z.namelist() and all(check.read(n)==z.read(n) for n in z.namelist() if n!='word/document.xml')
 name=old['name'].replace('word-windows-long-width','word-windows-grid-disabled');p=out/(name+'.docx');p.write_bytes(result);f=dict(old,name=name,source=str(p),source_sha256=sha(result),parent_name=old['name'],derived_parent=dict(file=old['source'],sha256=old['source_sha256']),run_snap_to_grid=False);rows.append(f)
assert len(rows)==2;p=T/'w20-grid-disabled-input-facts.json';assert not p.exists();p.write_bytes((json.dumps(rows,indent=2)+'\n').encode())