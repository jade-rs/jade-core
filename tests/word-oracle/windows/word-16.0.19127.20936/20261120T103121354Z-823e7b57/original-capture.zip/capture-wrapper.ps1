$ErrorActionPreference='Stop'
$taskOutput=Join-Path $PSScriptRoot 'w20-grid-disabled-word'
if(Test-Path -LiteralPath $taskOutput){throw 'Output exists; no original will be overwritten'}
$taskRows=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'w20-grid-disabled-input-facts.json') -Raw | ConvertFrom-Json -AsHashtable
if($taskRows.Count -ne 2){throw 'Missing inputs'}
foreach($taskRow in $taskRows){
    if((Get-FileHash -LiteralPath $taskRow.source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskRow.source_sha256){throw 'Input changed'}
}
$taskManifest=& (Join-Path $PSScriptRoot 'capture-word-windows-color-span-contexts.ps1') -Documents @($taskRows | ForEach-Object {$_.source}) -OutputDirectory $taskOutput -CaptureMetafiles
$taskCapture=Get-Content -LiteralPath $taskManifest -Raw | ConvertFrom-Json -AsHashtable
if($taskCapture.status -ne 'complete' -or $taskCapture.documents.Count -ne 2){throw 'Incomplete original capture'}
$taskInputs=Join-Path (Split-Path -Parent $taskManifest) 'inputs'
[void][IO.Directory]::CreateDirectory($taskInputs)
foreach($taskRow in $taskRows){
    $taskDocument=@($taskCapture.documents | Where-Object {$_.name -eq $taskRow.name})
    if($taskDocument.Count -ne 1 -or $taskDocument[0].sha256 -ne $taskRow.source_sha256 -or $taskDocument[0].open_mode -ne 'normal-read-only'){throw 'Original source/open mode mismatch'}
    if((Get-FileHash -LiteralPath $taskRow.source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskRow.source_sha256){throw 'Input changed after capture'}
    Copy-Item -LiteralPath $taskRow.source -Destination (Join-Path $taskInputs ($taskRow.name+'.docx'))
}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'w20-grid-disabled-manifests.json'),(ConvertTo-Json -InputObject @([string]$taskManifest)),[Text.UTF8Encoding]::new($false))
Write-Output "Captured2 original long-width controls, Word $($taskCapture.word.product_version), executable $($taskCapture.word.executable_sha256), manifest $taskManifest"
