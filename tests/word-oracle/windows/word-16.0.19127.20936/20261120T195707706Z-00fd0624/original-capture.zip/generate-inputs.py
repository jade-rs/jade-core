from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from io import BytesIO
from lxml import etree as E
import hashlib,json
T=Path(__file__).resolve().parent
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
# Reproduce every captured input from its original 12pt parent and declared size.
parents=json.loads((T/'w21-font-family-extended-input-facts.json').read_bytes())+json.loads((T/'w21-mincho-style-input-facts.json').read_bytes())
for f in json.loads((T/'w21-mincho-size96-input-facts.json').read_bytes()):
 parent=next(p for p in parents if p['source_sha256']==f['parent_source_sha256'])
 data=Path(parent['source']).read_bytes();assert hashlib.sha256(data).hexdigest()==parent['source_sha256']
 with ZipFile(BytesIO(data)) as z:
  tree=E.fromstring(z.read('word/document.xml'));runs=[r for r in tree.iter(W+'r') if r.find(W+'rPr/'+W+'rFonts') is not None];assert len(runs)==2
  for r in runs:
   for tag in ['sz','szCs']:
    node=r.find(W+'rPr/'+W+tag)
    if node is not None:
     assert node.get(W+'val')=='24';node.set(W+'val',str(f['font_size_pt']*2))
  xml=E.tostring(tree,encoding='utf-8',xml_declaration=True,standalone=True);out=BytesIO()
  with ZipFile(out,'w',ZIP_DEFLATED) as target:
   for item in z.infolist():
    info=ZipInfo(item.filename,(2026,11,21,0,0,0));info.create_system=0;info.compress_type=ZIP_DEFLATED;info.external_attr=item.external_attr;target.writestr(info,xml if item.filename=='word/document.xml' else z.read(item.filename))
 assert hashlib.sha256(out.getvalue()).hexdigest()==f['source_sha256']
 assert Path(f['source']).read_bytes()==out.getvalue()
print('Reproduced all96 input byte hashes from immutable parent sources and authored sizes')
