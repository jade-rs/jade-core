from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from io import BytesIO
from lxml import etree as E
import json,hashlib
T=Path(__file__).resolve().parent;W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';sha=lambda b:hashlib.sha256(b).hexdigest();parents=[f for f in json.loads((T/'w21-font-family-extended-input-facts.json').read_bytes()) if f['canonical_family'] in ('Yu Mincho','MS Mincho')];assert len(parents)==64
out=T/'w21-mincho-style-inputs';assert not out.exists();out.mkdir();rows=[]
for f in parents:
 source=Path(f['source']);data=source.read_bytes();assert sha(data)==f['source_sha256']
 for style,bold,italic in [('bold',True,False),('italic',False,True),('bolditalic',True,True)]:
  with ZipFile(BytesIO(data)) as z:
   tree=E.fromstring(z.read('word/document.xml'));runs=[r for r in tree.iter(W+'r') if r.find(W+'rPr/'+W+'rFonts') is not None];assert len(runs)==2
   for run in runs:
    props=run.find(W+'rPr')
    for flag,on in [('b',bold),('i',italic)]:
     node=props.find(W+flag)
     if node is None:node=E.SubElement(props,W+flag)
     node.set(W+'val','1' if on else '0')
   xml=E.tostring(tree,encoding='utf-8',xml_declaration=True,standalone=True);buffer=BytesIO()
   with ZipFile(buffer,'w',ZIP_DEFLATED) as target:
    for item in z.infolist():
     info=ZipInfo(item.filename,(2026,11,21,0,0,0));info.create_system=0;info.compress_type=ZIP_DEFLATED;info.external_attr=item.external_attr;target.writestr(info,xml if item.filename=='word/document.xml' else z.read(item.filename))
   result=buffer.getvalue()
   with ZipFile(BytesIO(result)) as check:assert z.namelist()==check.namelist() and all(z.read(n)==check.read(n) for n in z.namelist() if n!='word/document.xml')
  name=f['name'].replace('word-windows-family-extended-','word-windows-mincho-').replace('-s12-',f'-{style}-s12-');path=out/(name+'.docx');path.write_bytes(result);rows.append(dict(f,name=name,source=str(path),source_sha256=sha(result),parent_name=f['parent_name']+'-'+style,regular_family_case_parent=f['name'],regular_parent_sha256=f['source_sha256'],font_style=style,bold=bold,italic=italic,source_change='Only bold/italic flags on the two explicitly assigned family runs; East Asian Arial slot, following default run and all other package parts retained. No expected coordinates.'))
assert len(rows)==192;p=T/'w21-mincho-style-input-facts.json';assert not p.exists();p.write_bytes((json.dumps(rows,indent=2)+'\n').encode());print('Generated192 styled Mincho sources:48canonical/144aliases; actual Word required',flush=True)
