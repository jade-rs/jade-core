"""Source-only run-length controls to distinguish layout pitch from PDF accumulation."""
from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from io import BytesIO
from lxml import etree as E
import hashlib,json
T=Path(__file__).resolve().parent;R=T/'w19p';q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
sha=lambda b:hashlib.sha256(b).hexdigest();parent=json.loads((R/'tests/word-oracle/windows/positive-kerning-observations.json').read_bytes())
out=T/'w20-long-width-inputs';assert not out.exists();out.mkdir();facts=[]
for style in ('regular','bold','italic','bolditalic'):
 name=f'word-windows-positive-kern-{style}-s14-Z48-m14';old,=[c for c in parent['fixtures'] if c['name']==name];data=(R/old['source']['file']).read_bytes();assert sha(data)==old['source']['sha256']
 for token,character in (('at','@'),('m','m')):
  with ZipFile(BytesIO(data)) as z:
   tree=E.fromstring(z.read('word/document.xml'));texts=list(tree.iter(q('t')));kerns=list(tree.iter(q('kern')));assert len(texts)==len(kerns)==4
   specs=[]
   for t,k,length in zip(texts,kerns,(24,48,72,96)):
    assert t.text=='Z'*48;t.text=character*length;k.set(q('val'),'200');specs.append(dict(character=character,length=length,kerning_threshold_halfpoints=200))
   page,=tree.iter(q('pgSz'));page.set(q('w'),'31680')
   changed=E.tostring(tree,encoding='utf-8',xml_declaration=True,standalone=True);buf=BytesIO()
   with ZipFile(buf,'w',compression=ZIP_DEFLATED) as dest:
    for item in z.infolist():
     info=ZipInfo(item.filename,(2026,11,20,0,0,0));info.create_system=0;info.compress_type=ZIP_DEFLATED;info.external_attr=item.external_attr;dest.writestr(info,changed if item.filename=='word/document.xml' else z.read(item.filename))
   result=buf.getvalue()
   with ZipFile(BytesIO(result)) as check:
    assert check.namelist()==z.namelist() and all(check.read(n)==z.read(n) for n in z.namelist() if n!='word/document.xml')
  new=f'word-windows-long-width-{style}-s14-{token}-24to96-m14';p=out/(new+'.docx');p.write_bytes(result)
  facts.append(dict(name=new,source=str(p),source_sha256=sha(result),parent_name=name,derived_parent=old['source'],font_family='Aptos Display',font_style=style,font_size_pt=14,compatibility_mode=14,paragraphs=4,paragraph_specifications=specs,page_width_twips=31680,expected_non_whitespace_glyphs=240,changed_parts=['word/document.xml']))
p=T/'w20-long-width-input-facts.json';assert not p.exists();p.write_bytes((json.dumps(facts,indent=2)+'\n').encode());print('Generated8 long-width controls with independent24/48/72/96 lengths and fixed kerning-off',flush=True)