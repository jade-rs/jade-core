from pathlib import Path
from io import BytesIO
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import hashlib,json
from lxml import etree as E
T=Path(__file__).resolve().parent;R=T/'w19mf';read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest();q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
parents=read(R/'tests/word-oracle/windows/legacy-justification-observations.json')['fixtures'];out=T/'w19-legacy-mode-balance-inputs';assert not out.exists();out.mkdir();facts=[]
for row in parents:
 spec=row['input_specification']
 if not row['name'].startswith('word-windows-legacy-font-') or spec['compatibility_mode']!=14:continue
 for mode,balance in [(12,False)]+([(14,True),(15,True)] if spec['line_width_twips'] in (3000,8504) else []):
  source=(R/row['source']['file']).read_bytes();assert sha(source)==row['source']['sha256']
  with ZipFile(BytesIO(source)) as package:
   settings=E.fromstring(package.read('word/settings.xml'));compat,=[n for n in settings.iter(q('compatSetting')) if n.get(q('name'))=='compatibilityMode'];compat.set(q('val'),str(mode));node,=settings.iter(q('balanceSingleByteDoubleByteWidth'));node.set(q('val'),'1' if balance else '0');xml=E.tostring(settings,encoding='utf-8',xml_declaration=True,standalone=True);buffer=BytesIO()
   with ZipFile(buffer,'w',compression=ZIP_DEFLATED) as target:
    for info in package.infolist():
     item=ZipInfo(info.filename,(2026,11,19,0,0,0));item.create_system=0;item.compress_type=ZIP_DEFLATED;item.external_attr=info.external_attr;target.writestr(item,xml if info.filename=='word/settings.xml' else package.read(info.filename))
   data=buffer.getvalue()
   with ZipFile(BytesIO(data)) as target:assert all(target.read(n)==package.read(n) for n in package.namelist() if n!='word/settings.xml')
  name=row['name'].replace('legacy-font','legacy-mode-balance').replace('-m14-',f'-m{mode}-balance{int(balance)}-');dest=out/(name+'.docx');dest.write_bytes(data)
  facts.append(dict(name=name,source=str(dest),source_sha256=sha(data),derived_parent=row['source'],parent_name=row['name'],font_family=spec['font_family'],font_size_pt=spec['font_size_pt'],bold=spec['bold'],compatibility_mode=mode,balance_single_byte_double_byte_width=balance,line_ending=spec['line_ending'],line_width_twips=spec['line_width_twips'],text=spec['text'],following_text=spec['following_text'],expected_non_whitespace_glyphs=spec['expected_non_whitespace_glyphs'],changed_parts=['word/settings.xml']))
assert len(facts)==48 and len({r['source_sha256'] for r in facts})==48
(T/'w19-legacy-mode-balance-input-facts.json').write_bytes((json.dumps(facts,ensure_ascii=False,indent=2)+'\n').encode());s=(T/'capture-w19-aptos-style.ps1').read_text(encoding='utf-8-sig').replace('w19-aptos-style','w19-legacy-mode-balance').replace('-ne 96','-ne 48').replace('Captured96 original Aptos style/mode/balance controls','Captured48 original legacy mode/balance controls');(T/'capture-w19-legacy-mode-balance.ps1').write_bytes(s.encode());print('Prepared48 source-settings-only legacy12 and balanced14/15 controls',flush=True)
