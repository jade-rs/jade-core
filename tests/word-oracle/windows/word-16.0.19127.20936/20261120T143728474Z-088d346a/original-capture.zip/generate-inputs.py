from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from io import BytesIO
from lxml import etree as E
import json,hashlib
T=Path(__file__).resolve().parent;q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n;sha=lambda b:hashlib.sha256(b).hexdigest();parents=json.loads((T/'w20-long-width-input-facts.json').read_bytes());out=T/'w20-font-family-case-inputs';assert not out.exists();out.mkdir();rows=[]
for old in parents:
 source=Path(old['source']);data=source.read_bytes();assert sha(data)==old['source_sha256']
 for case,family in [('lower','aptos display'),('upper','APTOS DISPLAY'),('mixed','aPtOs dIsPlAy')]:
  for token,points in [('13',13),('14p5',14.5)]:
   with ZipFile(BytesIO(data)) as z:
    tree=E.fromstring(z.read('word/document.xml'));sizes=list(tree.iter(q('sz')));fonts=list(tree.iter(q('rFonts')));assert len(sizes)==len(fonts)==4
    for s in sizes:assert s.get(q('val'))=='28';s.set(q('val'),str(int(points*2)))
    for font in fonts:
     assert all(v=='Aptos Display' for k,v in font.attrib.items())
     for k in list(font.attrib):font.set(k,family)
    changed=E.tostring(tree,encoding='utf-8',xml_declaration=True,standalone=True);buf=BytesIO()
    with ZipFile(buf,'w',compression=ZIP_DEFLATED) as target:
     for item in z.infolist():
      info=ZipInfo(item.filename,(2026,11,20,0,0,0));info.create_system=0;info.compress_type=ZIP_DEFLATED;info.external_attr=item.external_attr;target.writestr(info,changed if item.filename=='word/document.xml' else z.read(item.filename))
    result=buf.getvalue()
    with ZipFile(BytesIO(result)) as check:assert check.namelist()==z.namelist() and all(check.read(n)==z.read(n) for n in z.namelist() if n!='word/document.xml')
   name=old['name'].replace('word-windows-long-width',f'word-windows-font-family-case-{case}').replace('-s14-',f'-s{token}-');path=out/(name+'.docx');path.write_bytes(result)
   rows.append(dict(old,name=name,source=str(path),source_sha256=sha(result),parent_name=old['name'],derived_parent=dict(file=str(source),sha256=old['source_sha256']),font_size_pt=points,font_family=family,font_family_case=case))
assert len(rows)==48;p=T/'w20-font-family-case-input-facts.json';assert not p.exists();p.write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print('Generated48 source-only controls; only run font spelling and sizes changed, every other ZIP member identical',flush=True)
