from pathlib import Path
from io import BytesIO
from copy import deepcopy
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import hashlib,json
from lxml import etree as E
T=Path(__file__).resolve().parent;R=T/'w19hs'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
index=read(R/'tests/word-oracle/windows/hard-break-space-observations.json')
out=T/'w19-legacy-font-inputs';assert not out.exists();out.mkdir();facts=[]
for family,bold,label in [('Arial',True,'arial-bold'),('Calibri',False,'calibri'),('Times New Roman',False,'times')]:
 for mode in (14,15):
  for ending in ('manual','paragraph'):
   parent=next(c for c in index['fixtures'] if c['name']==f'word-windows-hard-break-ea-arial-s12-m{mode}-{ending}-spaces0')
   data=(R/parent['source']['file']).read_bytes();assert sha(data)==parent['source']['sha256']
   for width in (3000,3400,4000,8504):
    with ZipFile(BytesIO(data)) as original:
     document=E.fromstring(original.read('word/document.xml'))
     paragraph,=document.iter(q('p'));properties=paragraph.find(q('pPr'))
     assert properties is not None and properties.find(q('ind')) is None
     indent=E.Element(q('ind'));indent.set(q('right'),str(8504-width));properties.insert(1,indent)
     run,=paragraph.iter(q('r'));fonts=run.find(q('rPr')).find(q('rFonts'))
     for slot in ('ascii','hAnsi','cs'):fonts.set(q(slot),family)
     if bold:
      run.find(q('rPr')).insert(1,E.Element(q('b')));run.find(q('rPr')).insert(2,E.Element(q('bCs')))
     text='Ag日本語 ABC Ag日本語';next(run.iter(q('t'))).text=text
     xml=E.tostring(document,encoding='utf-8',xml_declaration=True,standalone=True)
     buffer=BytesIO()
     with ZipFile(buffer,'w',compression=ZIP_DEFLATED) as package:
      for info in original.infolist():
       item=ZipInfo(info.filename,(2026,11,19,0,0,0));item.create_system=0;item.compress_type=ZIP_DEFLATED;item.external_attr=info.external_attr
       package.writestr(item,xml if info.filename=='word/document.xml' else original.read(info.filename))
     result=buffer.getvalue()
     with ZipFile(BytesIO(result)) as package:
      assert package.namelist()==original.namelist()
      assert all(package.read(n)==original.read(n) for n in original.namelist() if n!='word/document.xml')
    name=f'word-windows-legacy-font-{label}-s12-m{mode}-{ending}-w{width}'
    dest=out/(name+'.docx');dest.write_bytes(result)
    facts.append(dict(name=name,source=str(dest),source_sha256=sha(result),derived_parent=parent['source'],parent_name=parent['name'],
     font_family=family,bold=bold,font_size_pt=12,east_asia_font='Arial',compatibility_mode=mode,line_ending=ending,
     line_width_twips=width,right_indent_twips=8504-width,text=text,following_text='X' if ending=='manual' else '',
     expected_non_whitespace_glyphs=sum(not c.isspace() for c in text)+(ending=='manual'),changed_parts=['word/document.xml']))
p=T/'w19-legacy-font-input-facts.json';assert not p.exists();p.write_bytes((json.dumps(facts,ensure_ascii=False,indent=2)+chr(10)).encode())
wrapper=(T/'capture-w19-hard-break.ps1').read_text(encoding='utf-8-sig').replace('w19-hard-break','w19-legacy-font').replace('-ne 24','-ne 48').replace('Captured24 original hard-break controls','Captured48 original legacy-font controls')
p=T/'capture-w19-legacy-font.ps1';assert not p.exists();p.write_bytes(wrapper.encode())
print('Prepared48 original-font controls: Arialbold/Calibri/Times, modes14/15, four widths and natural/manual endings',flush=True)
