from pathlib import Path
from io import BytesIO
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import hashlib,json
from lxml import etree as E
T=Path(__file__).resolve().parent;R=T/'w19hs'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
index=read(R/'tests/word-oracle/windows/hard-break-space-observations.json')
out=T/'w19-space-pair-inputs';assert not out.exists();out.mkdir();facts=[]
for family,label in [('Arial','arial'),('Times New Roman','times')]:
 for mode in (14,15):
  parent=next(c for c in index['fixtures'] if c['name']==f'word-windows-hard-break-ea-arial-s12-m{mode}-paragraph-spaces0')
  data=(R/parent['source']['file']).read_bytes();assert sha(data)==parent['source']['sha256']
  for kern in (0,2):
   for tail in ('AA','BB','VA','TA'):
    with ZipFile(BytesIO(data)) as original:
     document=E.fromstring(original.read('word/document.xml'));run,=document.iter(q('r'));properties=run.find(q('rPr'));fonts=properties.find(q('rFonts'))
     for slot in ('ascii','hAnsi','cs'):fonts.set(q(slot),family)
     assert properties.find(q('kern')) is None
     setting=E.Element(q('kern'));setting.set(q('val'),str(kern));properties.insert(1,setting)
     text='AA '+tail;next(run.iter(q('t'))).text=text
     xml=E.tostring(document,encoding='utf-8',xml_declaration=True,standalone=True);buffer=BytesIO()
     with ZipFile(buffer,'w',compression=ZIP_DEFLATED) as target:
      for info in original.infolist():
       item=ZipInfo(info.filename,(2026,11,19,0,0,0));item.create_system=0;item.compress_type=ZIP_DEFLATED;item.external_attr=info.external_attr
       target.writestr(item,xml if info.filename=='word/document.xml' else original.read(info.filename))
     result=buffer.getvalue()
     with ZipFile(BytesIO(result)) as target:assert all(target.read(n)==original.read(n) for n in original.namelist() if n!='word/document.xml')
    name=f'word-windows-space-pair-{label}-s12-m{mode}-kern{kern}-aa-{tail.lower()}'
    dest=out/(name+'.docx');dest.write_bytes(result)
    facts.append(dict(name=name,source=str(dest),source_sha256=sha(result),derived_parent=parent['source'],parent_name=parent['name'],
     font_family=family,font_size_pt=12,compatibility_mode=mode,kerning_half_points=kern,text=text,
     expected_non_whitespace_glyphs=4,changed_parts=['word/document.xml']))
p=T/'w19-space-pair-input-facts.json';assert not p.exists();p.write_bytes((json.dumps(facts,ensure_ascii=False,indent=2)+chr(10)).encode())
wrapper=(T/'capture-w19-hard-break.ps1').read_text(encoding='utf-8-sig').replace('w19-hard-break','w19-space-pair').replace('-ne 24','-ne 32').replace('Captured24 original hard-break controls','Captured32 original space-pair controls')
p=T/'capture-w19-space-pair.ps1';assert not p.exists();p.write_bytes(wrapper.encode())
print('Prepared32 independent space-A/B/V/T controls: Arial/Times, modes14/15, kerningoff/on',flush=True)
