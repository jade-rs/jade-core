"""Source-only all-ASCII nominal widths to investigate the new W mismatch."""
from copy import deepcopy
from pathlib import Path
from io import BytesIO
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import hashlib,json
from lxml import etree as E
T=Path(__file__).resolve().parent;R=T/'w19p'
q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
sha=lambda b:hashlib.sha256(b).hexdigest()
index=json.loads((R/'tests/word-oracle/windows/positive-kerning-observations.json').read_bytes())
out=T/'w20-ascii-width-matrix-inputs';assert not out.exists();out.mkdir();facts=[]
for style in ('regular','bold','italic','bolditalic'):
    parent_name=f'word-windows-positive-kern-{style}-s14-Z48-m14'
    parent,=[c for c in index['fixtures'] if c['name']==parent_name]
    original=(R/parent['source']['file']).read_bytes();assert sha(original)==parent['source']['sha256']
    with ZipFile(BytesIO(original)) as source:
        document=E.fromstring(source.read('word/document.xml'));body,=document.iter(q('body'));old=body.findall(q('p'))
        assert len(old)==4 and all([t.text for t in p.iter(q('t'))]==['Z'*48] for p in old)
        template=deepcopy(old[0]);kern,=template.iter(q('kern'));assert kern.get(q('val'))=='200'
        position=body.index(old[0])
        for p in old:body.remove(p)
        paragraphs=[]
        for codepoint in range(33,127):
            p=deepcopy(template);text,=p.iter(q('t'));text.text=chr(codepoint)*48
            body.insert(position,p);position+=1;paragraphs.append(dict(character=chr(codepoint),codepoint=codepoint,length=48,kerning_threshold_halfpoints=200))
        changed=E.tostring(document,encoding='utf-8',xml_declaration=True,standalone=True);buffer=BytesIO()
        with ZipFile(buffer,'w',compression=ZIP_DEFLATED) as target:
            for item in source.infolist():
                info=ZipInfo(item.filename,(2026,11,20,0,0,0));info.create_system=0;info.compress_type=ZIP_DEFLATED;info.external_attr=item.external_attr
                target.writestr(info,changed if item.filename=='word/document.xml' else source.read(item.filename))
        data=buffer.getvalue()
        with ZipFile(BytesIO(data)) as checked:
            assert checked.namelist()==source.namelist()
            assert all(checked.read(n)==source.read(n) for n in source.namelist() if n!='word/document.xml')
    name=f'word-windows-ascii-width-matrix-{style}-s14-m14';path=out/(name+'.docx');path.write_bytes(data)
    facts.append(dict(name=name,source=str(path),source_sha256=sha(data),derived_parent=parent['source'],parent_name=parent_name,font_family='Aptos Display',font_style=style,font_size_pt=14,compatibility_mode=14,paragraphs=94,paragraph_specifications=paragraphs,expected_non_whitespace_glyphs=4512,changed_parts=['word/document.xml']))
assert len(facts)==4
p=T/'w20-ascii-width-matrix-input-facts.json';assert not p.exists();p.write_bytes((json.dumps(facts,indent=2)+'\n').encode());print('Generated4 fonts x94ASCIIparagraphs x48glyphs; unrelated package members unchanged',flush=True)
