from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from io import BytesIO
from lxml import etree as E
import hashlib,json
T=Path(__file__).resolve().parent;W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';sha=lambda b:hashlib.sha256(b).hexdigest()
parents=json.loads((T/'w21-font-family-extended-input-facts.json').read_bytes())+json.loads((T/'w21-mincho-style-input-facts.json').read_bytes())
parents=[f for f in parents if f['canonical_family'] in ('Yu Mincho','MS Mincho') and f['font_family_case']=='canonical' and f['line_ending']=='manual' and f['line_width_twips']==8504];assert len(parents)==16
out=T/'w21-mincho-manual-size96-inputs';assert not out.exists();out.mkdir();rows=[]
for f in parents:
 data=Path(f['source']).read_bytes();assert sha(data)==f['source_sha256']
 for size in [8,10,14,16,19,24]:
  with ZipFile(BytesIO(data)) as z:
   tree=E.fromstring(z.read('word/document.xml'));runs=[r for r in tree.iter(W+'r') if r.find(W+'rPr/'+W+'rFonts') is not None];assert len(runs)==2
   for r in runs:
    for tag in ['sz','szCs']:
     node=r.find(W+'rPr/'+W+tag)
     if node is not None:
      assert node.get(W+'val')=='24';node.set(W+'val',str(size*2))
   xml=E.tostring(tree,encoding='utf-8',xml_declaration=True,standalone=True);buffer=BytesIO()
   with ZipFile(buffer,'w',ZIP_DEFLATED) as target:
    for item in z.infolist():
     info=ZipInfo(item.filename,(2026,11,21,0,0,0));info.create_system=0;info.compress_type=ZIP_DEFLATED;info.external_attr=item.external_attr;target.writestr(info,xml if item.filename=='word/document.xml' else z.read(item.filename))
   result=buffer.getvalue()
   with ZipFile(BytesIO(result)) as check:assert z.namelist()==check.namelist() and all(z.read(n)==check.read(n) for n in z.namelist() if n!='word/document.xml')
  style=f.get('font_style','regular');face='yu' if f['canonical_family']=='Yu Mincho' else 'ms';name=f"word-windows-mincho-manual-size-{face}-{style}-s{size}-m{f['compatibility_mode']}-manual-w8504";p=out/(name+'.docx');p.write_bytes(result)
  rows.append(dict(f,name=name,source=str(p),source_sha256=sha(result),font_size_pt=size,font_style=style,parent_source_sha256=f['source_sha256'],source_change='Only font sizes on the two explicitly assigned family runs, including the following X in the same second run. Other package parts and all authored text/breaks retained. No expected coordinates generated.'))
assert len(rows)==96 and len({r['source_sha256'] for r in rows})==96
(T/'w21-mincho-manual-size96-input-facts.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode());print('Generated96 manual-break size controls; actual Word required',flush=True)
