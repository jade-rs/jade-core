from pathlib import Path
from io import BytesIO
from zipfile import ZipFile
import copy,hashlib,json,sys
from lxml import etree as E
T=Path(__file__).resolve().parent;R=T/'w19ma';sys.path.insert(0,str(R/'scripts/word-oracle'))
from generate_windows_legacy_justification_probes import changed_document
read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest();q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
parents={r['name']:r for r in read(R/'tests/word-oracle/windows/legacy-justification-observations.json')['fixtures']}
out=T/'w19-mixed-face-inputs';assert not out.exists();out.mkdir();facts=[]
for left,right,label in [('Arial','Calibri','arial-calibri'),('Arial','Times New Roman','arial-times'),('Calibri','Times New Roman','calibri-times')]:
 for mode in (14,15):
  for ending in ('manual','paragraph'):
   for width in (3000,8504):
    parent=parents[f'word-windows-legacy-font-calibri-s12-m{mode}-{ending}-w{width}'];source=(R/parent['source']['file']).read_bytes();assert sha(source)==parent['source']['sha256']
    with ZipFile(BytesIO(source)) as package:document=E.fromstring(package.read('word/document.xml'))
    paragraph,=document.iter(q('p'));second,=paragraph.iter(q('r'));first=copy.deepcopy(second)
    for node in list(first):
     if node.tag!=q('rPr'):first.remove(node)
    text=E.Element(q('t'));text.set('{http://www.w3.org/XML/1998/namespace}space','preserve');text.text='Ag日本語 ABC ';first.append(text)
    next(second.iter(q('t'))).text='Ag日本語'
    for run,family in ((first,left),(second,right)):
     fonts=run.find(q('rPr')).find(q('rFonts'))
     for slot in ('ascii','hAnsi','cs'):fonts.set(q(slot),family)
    paragraph.insert(list(paragraph).index(second),first)
    data=changed_document(source,E.tostring(document,encoding='utf-8',xml_declaration=True,standalone=True))
    with ZipFile(BytesIO(source)) as old,ZipFile(BytesIO(data)) as new:assert all(old.read(n)==new.read(n) for n in old.namelist() if n!='word/document.xml')
    name=f'word-windows-mixed-face-{label}-s12-m{mode}-{ending}-w{width}';path=out/(name+'.docx');path.write_bytes(data)
    facts.append(dict(name=name,source=str(path),source_sha256=sha(data),derived_parent=parent['source'],left_font_family=left,right_font_family=right,font_size_pt=12,compatibility_mode=mode,line_ending=ending,line_width_twips=width,left_text='Ag日本語 ABC ',right_text='Ag日本語',following_text='X' if ending=='manual' else '',expected_non_whitespace_glyphs=14 if ending=='manual' else 13,changed_parts=['word/document.xml']))
assert len(facts)==24 and len({r['source_sha256'] for r in facts})==24
(T/'w19-mixed-face-input-facts.json').write_bytes((json.dumps(facts,ensure_ascii=False,indent=2)+chr(10)).encode())
wrapper=(T/'capture-w19-space-pair.ps1').read_text(encoding='utf-8-sig').replace('w19-space-pair','w19-mixed-face').replace('-ne 32','-ne 24').replace('Captured32 original space-pair controls','Captured24 original mixed-face controls')
(T/'capture-w19-mixed-face.ps1').write_bytes(wrapper.encode())
print('Prepared24 two-face mixed-script sources; onlyrunfont/textsplit changes; independent paragraph/manual controls at2widths',flush=True)