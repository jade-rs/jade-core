from pathlib import Path
from io import BytesIO
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import hashlib,json
from lxml import etree as E
T=Path(__file__).resolve().parent;N=T/'w19mf';read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest();q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n;parents={r['name']:r for r in read(N/'tests/word-oracle/windows/legacy-justification-observations.json')['fixtures']};out=T/'w19-times-ea-inputs';assert not out.exists();out.mkdir();facts=[]
for east,label in [('Arial','arial'),('Calibri','calibri'),('Times New Roman','times'),('MS Mincho','msmincho')]:
 for balance in (0,1):
  for ending in ('manual','paragraph'):
   parent=parents[f'word-windows-legacy-font-times-s12-m14-{ending}-w8504'];source=(N/parent['source']['file']).read_bytes();assert sha(source)==parent['source']['sha256']
   with ZipFile(BytesIO(source)) as package:
    document=E.fromstring(package.read('word/document.xml'));settings=E.fromstring(package.read('word/settings.xml'));run,=document.iter(q('r'));fonts=run.find(q('rPr')).find(q('rFonts'));old_east=fonts.get(q('eastAsia'));fonts.set(q('eastAsia'),east);balanced,=settings.iter(q('balanceSingleByteDoubleByteWidth'));balanced.set(q('val'),str(balance));replacements={name:E.tostring(root,encoding='utf-8',xml_declaration=True,standalone=True) for name,root in [('word/document.xml',document),('word/settings.xml',settings)]};buffer=BytesIO()
    with ZipFile(buffer,'w',compression=ZIP_DEFLATED) as target:
     for info in package.infolist():
      item=ZipInfo(info.filename,(2026,11,19,0,0,0));item.create_system=0;item.compress_type=ZIP_DEFLATED;item.external_attr=info.external_attr;target.writestr(item,replacements.get(info.filename,package.read(info.filename)))
    data=buffer.getvalue()
    with ZipFile(BytesIO(data)) as target:assert all(package.read(n)==target.read(n) for n in package.namelist() if n not in replacements)
   name=f'word-windows-times-ea-{label}-s12-m14-balance{balance}-{ending}';path=out/(name+'.docx');path.write_bytes(data);facts.append(dict(name=name,source=str(path),source_sha256=sha(data),derived_parent=parent['source'],parent_name=parent['name'],font_family='Times New Roman',east_asia_font_family=east,parent_east_asia_font_family=old_east,font_size_pt=12,compatibility_mode=14,balance_single_byte_double_byte_width=bool(balance),line_ending=ending,line_width_twips=8504,text='Ag日本語 ABC Ag日本語',following_text='X' if ending=='manual' else '',expected_non_whitespace_glyphs=14 if ending=='manual' else 13,changed_parts=['word/document.xml','word/settings.xml']))
assert len(facts)==16; (T/'w19-times-ea-input-facts.json').write_bytes((json.dumps(facts,ensure_ascii=False,indent=2)+'\n').encode());wrapper=(T/'capture-w19-aptos-style.ps1').read_text(encoding='utf-8-sig').replace('w19-aptos-style','w19-times-ea').replace('-ne 96','-ne 16').replace('Captured96 original Aptos style/mode/balance controls','Captured16 original Times East Asia requested-font controls');(T/'capture-w19-times-ea.ps1').write_bytes(wrapper.encode());print('Prepared16 Times requestedEA4/balance2/natural-manual controls; parentsEAslots',sorted({r['parent_east_asia_font_family'] for r in facts}),flush=True)
