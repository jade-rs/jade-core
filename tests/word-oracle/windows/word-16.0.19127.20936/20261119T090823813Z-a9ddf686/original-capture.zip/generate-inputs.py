from pathlib import Path
from io import BytesIO
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import hashlib,json
from lxml import etree as E
T=Path(__file__).resolve().parent;R=T/'w19mf';read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest();q=lambda n:'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'+n
parents={r['name']:r for r in read(R/'tests/word-oracle/windows/legacy-justification-observations.json')['fixtures']};out=T/'w19-aptos-style-inputs';assert not out.exists();out.mkdir();facts=[]
for family,label in [('Aptos','aptos'),('Aptos Display','aptos-display')]:
 for mode in (12,14,15):
  for balance in (0,1):
   for bold,italic,style in [(False,False,'regular'),(True,False,'bold'),(False,True,'italic'),(True,True,'bolditalic')]:
    for ending in ('manual','paragraph'):
     parent=parents[f'word-windows-legacy-font-calibri-s12-m{14 if mode==12 else mode}-{ending}-w8504'];source=(R/parent['source']['file']).read_bytes();assert sha(source)==parent['source']['sha256']
     with ZipFile(BytesIO(source)) as package:
      document=E.fromstring(package.read('word/document.xml'));settings=E.fromstring(package.read('word/settings.xml'));run,=document.iter(q('r'));properties=run.find(q('rPr'));fonts=properties.find(q('rFonts'))
      for slot in ('ascii','hAnsi','cs'):fonts.set(q(slot),family)
      at=1
      for enabled,tags in ((bold,('b','bCs')),(italic,('i','iCs'))):
       for tag in tags:
        assert properties.find(q(tag)) is None
        if enabled:properties.insert(at,E.Element(q(tag)));at+=1
      balanced,=settings.iter(q('balanceSingleByteDoubleByteWidth'));balanced.set(q('val'),str(balance))
      modes=[n for n in settings.iter(q('compatSetting')) if n.get(q('name'))=='compatibilityMode'];assert len(modes)==1;modes[0].set(q('val'),str(mode))
      replacements={n:E.tostring(root,encoding='utf-8',xml_declaration=True,standalone=True) for n,root in [('word/document.xml',document),('word/settings.xml',settings)]};buffer=BytesIO()
      with ZipFile(buffer,'w',compression=ZIP_DEFLATED) as target:
       for info in package.infolist():
        item=ZipInfo(info.filename,(2026,11,19,0,0,0));item.create_system=0;item.compress_type=ZIP_DEFLATED;item.external_attr=info.external_attr;target.writestr(item,replacements.get(info.filename,package.read(info.filename)))
      data=buffer.getvalue()
      with ZipFile(BytesIO(data)) as target:assert all(target.read(n)==package.read(n) for n in package.namelist() if n not in replacements)
     name=f'word-windows-aptos-style-{label}-{style}-s12-m{mode}-balance{balance}-{ending}';path=out/(name+'.docx');path.write_bytes(data)
     facts.append(dict(name=name,source=str(path),source_sha256=sha(data),derived_parent=parent['source'],font_family=family,font_size_pt=12,bold=bold,italic=italic,style=style,compatibility_mode=mode,balance_single_byte_double_byte_width=bool(balance),line_ending=ending,line_width_twips=8504,text='Ag日本語 ABC Ag日本語',following_text='X' if ending=='manual' else '',expected_non_whitespace_glyphs=14 if ending=='manual' else 13,changed_parts=['word/document.xml','word/settings.xml']))
assert len(facts)==96 and len({r['source_sha256'] for r in facts})==96
(T/'w19-aptos-style-input-facts.json').write_bytes((json.dumps(facts,ensure_ascii=False,indent=2)+chr(10)).encode())
wrapper=(T/'capture-w19-space-pair.ps1').read_text(encoding='utf-8-sig').replace('w19-space-pair','w19-aptos-style').replace('-ne 32','-ne 96').replace('Captured32 original space-pair controls','Captured96 original Aptos style/mode/balance controls');(T/'capture-w19-aptos-style.ps1').write_bytes(wrapper.encode());print('Prepared96 Aptos2faces/4styles/3modes/balanceoff-on/natural-manual controls',flush=True)