$ErrorActionPreference='Stop'
$taskRows=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'w18-word-xps296-inputs.json') -Raw | ConvertFrom-Json -AsHashtable
$taskWord=New-Object -ComObject Word.Application
$taskWord.Visible=$false
$taskWord.DisplayAlerts=0
$taskWord.AutomationSecurity=3
try {
    $taskBinary=Join-Path $taskWord.Path 'WINWORD.EXE'
    $taskVersion=[Diagnostics.FileVersionInfo]::GetVersionInfo($taskBinary)
    $taskHash=(Get-FileHash -LiteralPath $taskBinary -Algorithm SHA256).Hash.ToLowerInvariant()
    $taskId=[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8)
    $taskOutput=Join-Path $PSScriptRoot ('w18-word-xps296/word-'+$taskVersion.ProductVersion+'/'+$taskId)
    if(Test-Path -LiteralPath $taskOutput){throw 'Existing evidence cannot be overwritten'}
    [void][IO.Directory]::CreateDirectory($taskOutput)
    $taskCapture=[ordered]@{schema=1;capture_id=$taskId;platform='windows';purpose='Actual Word XPS print origins for296 locked Aptos control inputs, independent of original PDF and EMF captures';api_reference='https://learn.microsoft.com/en-us/office/vba/api/word.document.exportasfixedformat';captured_at_utc=[DateTime]::UtcNow.ToString('o');word=[ordered]@{product_version=$taskVersion.ProductVersion;file_version=$taskVersion.FileVersion;application_version=$taskWord.Version;application_build=$taskWord.Build;executable_sha256=$taskHash};active_printer=[string]$taskWord.ActivePrinter;documents=@()}
    foreach($taskRow in $taskRows){
        $taskPath=[string]$taskRow.source
        if((Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskRow.source_sha256){throw 'Source hash mismatch'}
        $taskDoc=$taskWord.Documents.Open($taskPath,$false,$true,$false)
        try {
            $taskDoc.ActiveWindow.View.Type=3
            $taskDoc.Repaginate()
            $taskRecord=[ordered]@{name=$taskRow.name;source=$taskPath;source_sha256=$taskRow.source_sha256;compatibility_mode=[int]$taskDoc.CompatibilityMode;open_mode='normal-read-only';outputs=@()}
            foreach($taskMode in @(@{name='print-xps';format=18;optimize=0;pdfa=$false;extension='xps'})){
                $taskFile=$taskRow.name+'.'+$taskMode.name+'.'+$taskMode.extension
                $taskTarget=Join-Path $taskOutput $taskFile
                $taskDoc.ExportAsFixedFormat($taskTarget,$taskMode.format,$false,$taskMode.optimize,0,1,1,0,$true,$true,0,$true,$true,$taskMode.pdfa)
                $taskRecord.outputs+=,[ordered]@{context=$taskMode.name;format=$taskMode.format;optimize_for=$taskMode.optimize;use_iso19005_1=$taskMode.pdfa;file=$taskFile;sha256=(Get-FileHash -LiteralPath $taskTarget -Algorithm SHA256).Hash.ToLowerInvariant()}
            }
            if((Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskRow.source_sha256){throw 'Original DOCX changed'}
            $taskCapture.documents+=,$taskRecord
            $taskCapture|ConvertTo-Json -Depth 10|Set-Content -LiteralPath (Join-Path $taskOutput 'capture.json') -Encoding utf8
            Write-Output "Captured original Word XPS context $($taskRow.name)"
        } finally {$taskDoc.Close(0);[void][Runtime.InteropServices.Marshal]::ReleaseComObject($taskDoc)}
    }
    if((Get-FileHash -LiteralPath $taskBinary -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskHash){throw 'Word binary changed during capture'}
    $taskCapture.status='complete'
    $taskCapture|ConvertTo-Json -Depth 10|Set-Content -LiteralPath (Join-Path $taskOutput 'capture.json') -Encoding utf8
    [ordered]@{capture=(Join-Path $taskOutput 'capture.json');sha256=(Get-FileHash -LiteralPath (Join-Path $taskOutput 'capture.json') -Algorithm SHA256).Hash.ToLowerInvariant()}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'w18-word-xps296-capture.json') -Encoding utf8
    Write-Output "Complete versioned capture $taskOutput"
} finally {$taskWord.Quit();[void][Runtime.InteropServices.Marshal]::ReleaseComObject($taskWord)}
